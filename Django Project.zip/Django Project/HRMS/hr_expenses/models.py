from django.db import models
from hr_jobs.models import JobModel
from hr_tags.models import EmployeeTagModel

# Create your models here.
from django.utils import timezone

class ExpenseModel(models.Model):

    class Meta:
        permissions = (
            ("view_expensemodel", "Can view expense model"),
        )

    daily_expense = models.IntegerField(verbose_name='daily_expense')
    monthly_expense = models.IntegerField(verbose_name='monthly_expense')
    yearly_expense = models.IntegerField(verbose_name='yearly_expense')
    total_expense = models.IntegerField(verbose_name='total_expense')
    start_date = models.DateField(verbose_name='Start Date', default=timezone.now)
    end_date = models.DateField(verbose_name='End Date', default=timezone.now)
    note = models.TextField(max_length=100, verbose_name='Note')  
    status = models.CharField(max_length=10, verbose_name='Status', default='draft')
    is_active = models.BooleanField(verbose_name='Is Active', default=False)  
    create_date = models.DateTimeField(verbose_name='Create Date', default=timezone.now)
    attachment = models.ImageField(verbose_name='Image', default=None)
    job = models.ForeignKey(JobModel, on_delete=models.CASCADE, default=None)
    tags = models.ManyToManyField(EmployeeTagModel)

    def __str__(self):
        return self.daily_expense
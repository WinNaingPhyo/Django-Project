from django.views.generic import ListView, CreateView, DeleteView, UpdateView, DetailView
from django.urls import reverse_lazy
from hr_expenses import models
from hr_expenses import forms
from django.shortcuts import render, redirect
from django.contrib.auth.mixins import LoginRequiredMixin, PermissionRequiredMixin
from django.db.models import Q
from django.views import View
from .models import ExpenseModel

class search_by(View):

    def get(self, request):
        search = request.GET.get('search')
        if search:    
            expenses = ExpenseModel.objects.filter(
                Q(daily_expense__icontains=search) | 
                Q(monthly_expense__icontains=search) |
                Q(yearly_expense__icontains=search) |
                Q(total_expense__icontains=search) |
                Q(start_date__icontains=search) |
                Q(end_date__icontains=search) |
                Q(note__icontains=search) |
                Q(status__icontains=search) |
                Q(is_active__icontains=search) |
                Q(create_date__icontains=search)
            )
        else:
            expenses = ExpenseModel.objects.all()
        return render(request, 'expense_list.html', {'all_expenses': expenses})

class order_by(View):

    def get(self, request):
        order = request.GET.get('order')
        expenses = ExpenseModel.objects.all().order_by("-"+ order)
        order_selected = {str(order): 'btn-primary text-white'}
        return render(request, 'expense_list.html', {'all_expenses': expenses, 'order_selected': order_selected})

class ExpenseDetailView(PermissionRequiredMixin, DetailView):
    login_url = 'login'
    permission_required = 'hr_expenses.view_expensemodel'
    model = models.ExpenseModel
    context_object_name = "expense"
    template_name = 'expense_detail.html'

class ExpenseListView(LoginRequiredMixin, ListView):
    paginate_by = 1
    login_url = 'login'
    model = models.ExpenseModel
    context_object_name = 'all_expenses'
    template_name = 'expense_list.html'

class ExpenseCreateView(PermissionRequiredMixin, CreateView):
    login_url = 'login'
    permission_required = 'hr_expenses.add_expensemodel'
    success_url = reverse_lazy("expense_list")
    model = models.ExpenseModel
    form_class = forms.ExpenseForm
    template_name = 'expense_create.html'

class ExpenseUpdateView(PermissionRequiredMixin, UpdateView):
    login_url = 'login'
    permission_required = 'hr_expenses.change_expensemodel'
    success_url = reverse_lazy("expense_list")
    model = models.ExpenseModel
    form_class = forms.ExpenseForm
    context_object_name = "expense"
    template_name = 'expense_update.html'

class ExpenseDeleteView(PermissionRequiredMixin, DeleteView):
    # success_url = reverse_lazy("expense_list")
    # model = models.expenseModel
    # context_object_name = "expense"

    # def get(self, request, *args, **kwargs):
    #     return self.post(request, *args, **kwargs)

    login_url = 'login'
    permission_required = 'hr_expenses.delete_expensemodel'

    def get(self, request, pk):
        expense = models.ExpenseModel.objects.get(id=pk)  
        expense.delete()
        return redirect('expense_list')
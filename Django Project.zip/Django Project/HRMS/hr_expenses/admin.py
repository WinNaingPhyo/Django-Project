from django.contrib import admin

# Register your models here.
from .models import ExpenseModel
# from file_name import class_name

admin.site.register(ExpenseModel)
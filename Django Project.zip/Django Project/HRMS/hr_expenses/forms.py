from django import forms
from django.forms import widgets
from .models import ExpenseModel

STATUS_CHOICES =(
    ('draft', 'draft'),
    ('Confirm', 'confirm'),
    ('Cancel', 'cancel')
)

class ExpenseForm(forms.ModelForm):
    
    class Meta:
        model = ExpenseModel
        fields = "__all__"
        labels  = {
            'daily_expense':'Daily Expense', 
            'monthly_expense':'Enter Monthly Expense',  
            'yearly_expense':'Enter Yearly Expense',
            'total_expense':'Total Expense',
            'note':'Internal Note', 
            'status':'Status', 
            'is_active':'Is Active', 
            'create_date':'Enter Create Date', 
            'attachment':'Upload Attachment'
        }
        widgets = {
            'daily_expense': widgets.NumberInput(attrs={'placeholder':'Daily Expense','class': 'form-control'}),
            'monthly_expense': widgets.NumberInput(attrs={'placeholder':'Monthly Expense','class': 'form-control'}),
            'yearly_expense': widgets.NumberInput(attrs={'placeholder':'Yearly Expense','class': 'form-control'}),
            'total_expense': widgets.NumberInput(attrs={'placeholder':'Total Expense','class': 'form-control'}),
            'note': widgets.TextInput(attrs={'placeholder':'Internal Note','class': 'form-control'}),
            'status': widgets.Select(choices=STATUS_CHOICES, attrs={'class': 'form-control'}),
            'is_active': widgets.CheckboxInput(),
            'create_date': widgets.DateTimeInput(attrs={'type':'datetime-local','class': 'form-control'}),
            #'attachment': widgets.ClearableFileInput()
        }
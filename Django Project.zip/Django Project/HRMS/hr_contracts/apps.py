from django.apps import AppConfig


class HrContractsConfig(AppConfig):
    name = 'hr_contracts'

from django.shortcuts import render, redirect
from .models import EmployeeModel
from datetime import datetime
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, permission_required
from django.db.models import Q
from hr_jobs.models import JobModel
from hr_tags.models import EmployeeTagModel
from django.core.paginator import Paginator

# Create your views here.
def search_by(request):
    search = request.GET.get('search')
    if search:    
        employees = EmployeeModel.objects.filter(
            Q(name__icontains=search) | 
            Q(age__icontains=search) |
            Q(birthday__icontains=search) |
            Q(address__icontains=search) |
            Q(email__icontains=search) |
            Q(gender__icontains=search) |
            Q(joining_date__icontains=search)
        )
    else:      
        employees = EmployeeModel.objects.all()
    return render(request, 'employee_list.html', {'all_employees': employees})

def order_by(request):
    order = request.GET.get('order')
    employees = EmployeeModel.objects.all().order_by("-"+ order)
    order_selected = {str(order): 'btn-primary text-white'}
    return render(request, 'employee_list.html', {'all_employees': employees, 'order_selected': order_selected})

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            # Save session as cookie to login the user
            login(request, user)
            return redirect('/hr_employees/show_employee/')
        else:
            return render(request, 'login.html', {'error_message': 'Incorrect username and / or password.'})
    else:
        return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('/login')  

@permission_required('hr_employees.view_employeemodel', login_url='login')
def employee(request, employee_id):
    if request.method == "GET": 
        employee = EmployeeModel.objects.get(id=employee_id)  
        return render(request,'employee_detail.html', {'employee': employee})

@login_required(login_url='login')
def all_employees(request):
    if request.method == "GET": 
        all_employees = EmployeeModel.objects.all()
        paginator = Paginator(all_employees, 1)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        return render(request,'employee_list.html', {'page_obj': page_obj})

@permission_required('hr_employees.add_employeemodel', login_url='login')  
def add_employee(request):  
    if request.method == "GET":
        print('Save GET call +++++++++++++++++++++')
        employee = EmployeeModel()
        jobs = JobModel.objects.all()
        tags = EmployeeTagModel.objects.all()
        context = {'employee': employee, 'jobs': jobs, 'tags': tags}
        return render(request,'employee_create.html', context)
    if request.method == "POST" and request.FILES['image']:
        print('Save POST call +++++++++++++++++++++')
        print('data => ', request.POST)
        name = request.POST.get('name')
        age = request.POST.get('age')
        birthday = request.POST.get('birthday')
        address = request.POST.get('address')
        email = request.POST.get('email')
        gender = request.POST.get('gender')
        if request.POST.get('is_married') == 'on':
           is_married = True
        else:
           is_married = False
        joining_date = request.POST.get('joining_date')
        image = request.FILES.get('image')
        # 88, 89, 97, 102
        job = request.POST.get('job')
        tags = request.POST.getlist('tags')
        employee = EmployeeModel.objects.create(
            name=name, 
            age=age, 
            birthday=birthday,
            address=address,
            email=email,
            gender=gender,
            job_id=job,
            is_married=is_married,
            joining_date=joining_date,
            image=image
        )
        employee.tags.set(tags)
        employee.save()
        return redirect('/hr_employees/show_employee/')  

@permission_required('hr_employees.change_employeemodel', login_url='login')  
def update_employee(request, employee_id):  
    employee = EmployeeModel.objects.get(id=employee_id)  
    if request.method == "GET":
        print('Update GET call ++++++++++++++++++++++++++++++++++')
        employee.birthday = str(employee.birthday)
        employee.joining_date = datetime.strftime(employee.joining_date, '%Y-%m-%dT%H:%M')
        jobs = JobModel.objects.all()
        tags = EmployeeTagModel.objects.all()
        context = {'employee': employee, 'uploaded_image': employee.image, 'jobs': jobs, 'tags': tags}
        return render(request, 'employee_update.html', context)
    elif request.method == "POST": 
        print('Update POST call ++++++++++++++++++++++++++++++++++')
        print('data =>' , request.POST)
        employee.name = request.POST.get('name')
        employee.age = request.POST.get('age')
        employee.birthday = request.POST.get('birthday')
        employee.address = request.POST.get('address')
        employee.email = request.POST.get('email')
        employee.gender = request.POST.get('gender')
        #127, 128
        employee.job_id = request.POST.get('job')
        employee.tags.set(request.POST.getlist('tags'))
        if request.POST.get('is_married') == 'on':
           employee.is_married = True
        else:
           employee.is_married = False
        #employee.is_married = request.POST.get('is_married')
        employee.joining_date = request.POST.get('joining_date')
        if request.FILES.get('image'):
            employee.image = request.FILES.get('image')
        employee.save()
        return redirect('/hr_employees/detail/' + str(employee_id) + '/')

@permission_required('hr_employees.delete_employeemodel', login_url='login')  
def delete_employee(request, employee_id):
    print('delete_employee call')
    if request.method == "GET": 
        print('delete GET call +++++++++++++++++++++++++++')
    #     employee = EmployeeModel.objects.get(id=employee_id)  
    #     return render(request, 'employee_delete.html', {'employee': employee})
    # if request.method == "POST": 
    #     print('delete POST call ++++++++++++++++++++++++++')
    #     print(request.POST)
        employee = EmployeeModel.objects.filter(id=employee_id)
        employee.delete()
        return redirect('/hr_employees/show_employee/')
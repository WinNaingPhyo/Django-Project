from django.shortcuts import render, redirect
from .models import PayrollModel
from datetime import datetime
from django.db.models import Q
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, permission_required, user_passes_test
from django.core.paginator import Paginator
from hr_departments.models import DepartmentModel
from hr_tags.models import JobTagModel

def search_by(request):
    search = request.GET.get('search')
    if search:    
        payrolls = PayrollModel.objects.filter(
            Q(name__icontains=search) | 
            Q(total_payroll__icontains=search) |
            Q(parttime_payroll__icontains=search) |
            Q(fulltime_payroll__icontains=search) |
            Q(parttime_employee__icontains=search) |
            Q(fulltime_employee__icontains=search) |
            Q(address__icontains=search) |
            Q(allowance__icontains=search) |
            Q(total_employee__icontains=search) |
            Q(leave_without_pay__icontains=search) |
            Q(monthly_bonus__icontains=search) |
            Q(yearly_bonus__icontains=search) |
            Q(is_paid=search) |
            Q(joining_date__icontains=search)
        )
    else:      
        payrolls = PayrollModel.objects.all()
    return render(request, 'payroll_list.html', {'all_payrolls': payrolls})

def order_by(request):
    order = request.GET.get('order')
    payrolls = PayrollModel.objects.all().order_by("-"+ order)
    order_selected = {str(order): 'btn-primary text-white'}
    return render(request, 'payroll_list.html', {'all_payrolls': payrolls, 'order_selected': order_selected})

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            # Save session as cookie to login the user
            login(request, user)
            return redirect('/hr_payrolls/show_payroll/')
        else:
            return render(request, 'login.html', {'error_message': 'Incorrect username and / or password.'})
    else:
        return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('/login')
    
@permission_required('hr_payrolls.view_payrollmodel', login_url='login')
def payroll(request, payroll_id):
    if request.method == "GET": 
        payroll = PayrollModel.objects.get(id=payroll_id)  
        return render(request,'payroll_detail.html', {'payroll': payroll})

def all_payrolls(request):
    if request.method == "GET": 
        all_payrolls = PayrollModel.objects.all()
        paginator = Paginator(all_payrolls,1)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        return render(request,'payroll_list.html', {'page_obj': page_obj})

@permission_required('hr_payrolls.add_payrollmodel', login_url='login')  
def add_payroll(request):  
    if request.method == "GET":
        payroll = PayrollModel()
        departments = DepartmentModel.objects.all()
        tags = JobTagModel.objects.all()
        context = {'payroll': payroll, 'departments': departments, 'tags': tags}
        return render(request,'payroll_create.html', context)
    if request.method == "POST" and request.FILES['image']:
        print('Save POST call +++++++++++++++++++++')
        print('data => ', request.POST)
        name = request.POST.get('name')
        total_payroll = request.POST.get('total_payroll')
        parttime_payroll = request.POST.get('parttime_payroll')
        fulltime_payroll = request.POST.get('fulltime_payroll')
        parttime_employee = request.POST.get('parttime_employee')
        fulltime_employee = request.POST.get('fulltime_employee')
        address = request.POST.get('address')
        allowance = request.POST.get('allowance')
        total_employee = request.POST.get('total_employee')
        leave_without_pay = request.POST.get('leave_without_pay')
        monthly_bonus = request.POST.get('monthly_bonus')
        yearly_bonus = request.POST.get('yearly_bonus')
        if request.POST.get('is_paid') == 'on':
           is_paid = True
        else:
           is_paid = False
        joining_date = request.POST.get('joining_date')
        image = request.FILES.get('image')
        department = request.POST.get('department')
        tags = request.POST.getlist('tags')
        payroll = PayrollModel.objects.create(
            name=name,
            total_payroll=total_payroll,
            parttime_payroll=parttime_payroll,
            fulltime_payroll=fulltime_payroll,
            parttime_employee=parttime_employee,
            fulltime_employee=fulltime_employee,
            address=address,
            allowance=allowance,
            total_employee=total_employee,
            leave_without_pay=leave_without_pay,
            monthly_bonus=monthly_bonus,
            yearly_bonus=yearly_bonus,
            department_id=department,
            is_paid=is_paid,
            joining_date=joining_date,
            image=image
        )
        payroll.tags.set(tags)
        payroll.save()
        return redirect('/hr_payrolls/show_payroll/')

@permission_required('hr_payrolls.change_payrollmodel', login_url='login')  
def update_payroll(request, payroll_id):  
    payroll = PayrollModel.objects.get(id=payroll_id)  
    if request.method == "GET":
        payroll.joining_date = datetime.strftime(payroll.joining_date, '%Y-%m-%dT%H:%M')
        context = {'payroll': payroll, 'uploaded_image': payroll.image}
        departments = DepartmentModel.objects.all()
        tags = JobTagModel.objects.all()
        context = {'payroll': payroll, 'departments': departments, 'tags': tags}
        return render(request, 'payroll_update.html', context)
    elif request.method == "POST": 
        payroll.name = request.POST.get('name')
        payroll.total_payroll = request.POST.get('total_payroll')
        payroll.parttime_payroll = request.POST.get('parttime_payroll')
        payroll.fulltime_payroll = request.POST.get('fulltime_payroll')
        payroll.parttime_employee = request.POST.get('parttime_employee')
        payroll.fulltime_employee = request.POST.get('fulltime_employee')
        payroll.address = request.POST.get('address')
        payroll.allowance = request.POST.get('allowance')
        payroll.total_employee = request.POST.get('total_employee')
        payroll.leave_without_pay = request.POST.get('leave_without_pay')
        payroll.monthly_bonus = request.POST.get('monthly_bouns')
        payroll.yearly_bonus = request.POST.get('yearly_bouns')
        payroll.department_id = request.POST.get('department')
        payroll.tags.set(request.POST.getlist('tags'))
        #payroll.is_paid = request.POST.get('is_paid')
        if request.POST.get('is_paid') == 'on':
           payroll.is_paid = True
        else:
           payroll.is_paid = False
        payroll.joining_date = request.POST.get('joining_date')
        if request.FILES.get('image'):
            payroll.image = request.FILES.get('image')
        payroll.save()
        return redirect('/hr_payrolls/detail/' + str(payroll_id) + '/')

@permission_required('hr_payrolls.delete_payrollmodel', login_url='login')  
def delete_payroll(request, payroll_id):
    if request.method == "GET": 
        payroll = PayrollModel.objects.get(id=payroll_id)
        payroll.delete()
        return redirect('/hr_payrolls/show_payroll/')
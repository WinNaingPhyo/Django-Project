from django.db import models
from hr_departments.models import DepartmentModel
from hr_tags.models import JobTagModel

# Create your models here.
from django.utils import timezone

class PayrollModel(models.Model):

    class Meta:
        permissions = (
            ("view_payrollmodel", "Can view payroll model"),
        )

    name = models.CharField(max_length=20, verbose_name='Name')
    total_payroll = models.IntegerField(verbose_name='Total Payroll')
    parttime_payroll = models.IntegerField(verbose_name='Parttime Payroll')
    fulltime_payroll = models.IntegerField(verbose_name='Fulltime Payroll')
    parttime_employee = models.IntegerField(verbose_name='Parttime Employee')
    fulltime_employee = models.IntegerField(verbose_name='Fulltime Employee')
    address = models.TextField(max_length=100, verbose_name='Address')
    allowance = models.IntegerField(verbose_name='Allowance', default='')
    total_employee = models.IntegerField(verbose_name='Total Employee')
    leave_without_pay = models.IntegerField(verbose_name='Leave without Pay')
    monthly_bonus = models.IntegerField (verbose_name='Monthly Bonus')
    yearly_bonus = models.IntegerField (verbose_name='Yearly Bonus')
    is_paid = models.BooleanField(verbose_name='Is Paid', default=False)
    joining_date = models.DateTimeField(verbose_name='Joining Date', default=timezone.now)
    image = models.ImageField(verbose_name='Image', default=None)
    department = models.ForeignKey(DepartmentModel, on_delete=models.CASCADE, default=None)
    tags = models.ManyToManyField(JobTagModel)

    def __str__(self):
        return self.name

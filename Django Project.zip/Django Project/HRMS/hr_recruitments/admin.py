from django.contrib import admin

# Register your models here.
from .models import ResumeModel
# from file_name import class_name

admin.site.register(ResumeModel)
from django.db import models
from hr_departments.models import DepartmentModel
from hr_tags.models import JobTagModel

# Create your models here.
from django.utils import timezone

class AttendanceModel(models.Model):

    class Meta:
        permissions = (
            ("view_attendancemodel", "Can view attendance model"),
        )

    name = models.CharField(max_length=20, verbose_name='Name')
    age = models.IntegerField(verbose_name='Age')
    birthday = models.DateField(verbose_name='Birthday', default=timezone.now)
    address = models.TextField(max_length=100, verbose_name='Address')  
    email = models.EmailField(max_length=50, default='test@gmail.com')
    phone = models.IntegerField(verbose_name='Phone Number')
    check_in =models.TimeField(verbose_name='Check In', default=timezone.now)
    check_out =models.TimeField(verbose_name='Check Out', default=timezone.now)
    break_time =models.TimeField(verbose_name='Break Time', default=timezone.now)
    lunch_time =models.TimeField(verbose_name='Lunch Time', default=timezone.now)
    gender = models.CharField(max_length=10, verbose_name='Gender', default='other')
    is_married = models.BooleanField(verbose_name='Is Married', default=False) 
    joining_date = models.DateTimeField(verbose_name='Joining Date', default=timezone.now)
    image = models.ImageField(verbose_name='Image', default=None)
    department = models.ForeignKey(DepartmentModel, on_delete=models.CASCADE, default=None)
    tags = models.ManyToManyField(JobTagModel)

    def __str__(self):
        return self.name

from django.shortcuts import render, redirect
from .models import AttendanceModel
from datetime import datetime
from django.db.models import Q
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required, permission_required, user_passes_test
from django.core.paginator import Paginator
from hr_departments.models import DepartmentModel
from hr_tags.models import JobTagModel

# Create your views here.

def search_by(request):
    search = request.GET.get('search')
    if search:    
        attendances = AttendanceModel.objects.filter(
            Q(name__icontains=search) | 
            Q(age__icontains=search) |
            Q(birthday__icontains=search) |
            Q(address__icontains=search) |
            Q(email__icontains=search) |
            Q(phone__icontains=search) |
            Q(check_in__icontains=search) |
            Q(check_out__icontains=search) |
            Q(break_time__icontains=search) |
            Q(lunch_time__icontains=search) |
            Q(gender__icontains=search) |
            Q(joining_date__icontains=search)
        )
    else:      
        attendances = AttendanceModel.objects.all()
    return render(request, 'attendance_list.html', {'all_attendances': attendances})

def order_by(request):
    order = request.GET.get('order')
    attendances = AttendanceModel.objects.all().order_by("-"+ order)
    order_selected = {str(order): 'btn-primary text-white'}
    return render(request, 'attendance_list.html', {'all_attendances': attendances, 'order_selected': order_selected})

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user is not None:
            # Save session as cookie to login the user
            login(request, user)
            return redirect('/hr_attendances/show_attendance/')
        else:
            return render(request, 'login.html', {'error_message': 'Incorrect username and / or password.'})
    else:
        return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('/login')

@permission_required('hr_attendances.view_attendancemodel', login_url='login')
def attendance(request, attendance_id):
    if request.method == "GET": 
        attendance = AttendanceModel.objects.get(id=attendance_id)  
        return render(request,'attendance_detail.html', {'attendance': attendance})

# def attendance(request, attendance_id):
#     if request.method == "GET": 
#         attendance = AttendanceModel.objects.get(id=attendance_id)  
#         return render(request,'attendance_detail.html', {'attendance': attendance})

def all_attendances(request):
    if request.method == "GET": 
        all_attendances = AttendanceModel.objects.all()
        paginator = Paginator(all_attendances, 1)
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        return render(request,'attendance_list.html', {'page_obj': page_obj})

@permission_required('hr_attendances.add_attendancemodel', login_url='login')  
def add_attendance(request):  
    if request.method == "GET":
        attendance = AttendanceModel()
        departments = DepartmentModel.objects.all()
        tags = JobTagModel.objects.all()
        context = {'attendance': attendance, 'departments': departments, 'tags': tags}
        return render(request,'attendance_create.html', context)
    if request.method == "POST" and request.FILES['image']:
        name = request.POST.get('name')
        age = request.POST.get('age')
        birthday = request.POST.get('birthday')
        address = request.POST.get('address')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        check_in = request.POST.get('check_in')
        check_out = request.POST.get('check_out')
        break_time = request.POST.get('break_time')
        lunch_time = request.POST.get('lunch_time')
        gender = request.POST.get('gender')
        if request.POST.get('is_married') == 'on':
           is_married = True
        else:
           is_married = False
        joining_date = request.POST.get('joining_date')
        image = request.FILES.get('image')
        department = request.POST.get('department')
        tags = request.POST.getlist('tags')
        attendance = AttendanceModel.objects.create(
            name=name, 
            age=age, 
            birthday=birthday,
            address=address,
            email=email,
            phone=phone,
            check_in=check_in,
            check_out=check_out,
            break_time=break_time,
            lunch_time=lunch_time,
            gender=gender,
            department_id=department,
            is_married=is_married,
            joining_date=joining_date,
            image=image
        )
        attendance.tags.set(tags)
        attendance.save()
        return redirect('/hr_attendances/show_attendance/')

@permission_required('hr_attendances.change_attendancemodel', login_url='login')  
def update_attendance(request, attendance_id):  
    attendance = AttendanceModel.objects.get(id=attendance_id)  
    if request.method == "GET":
        attendance.birthday = str(attendance.birthday)
        attendance.joining_date = datetime.strftime(attendance.joining_date, '%Y-%m-%dT%H:%M')
        context = {'attendance': attendance, 'uploaded_image': attendance.image}
        departments = DepartmentModel.objects.all()
        tags = JobTagModel.objects.all()
        context = {'attendance': attendance, 'departments': departments, 'tags': tags}
        return render(request, 'attendance_update.html', context)
    elif request.method == "POST": 
        attendance.name = request.POST.get('name')
        attendance.age = request.POST.get('age')
        attendance.birthday = request.POST.get('birthday')
        attendance.address = request.POST.get('address')
        attendance.email = request.POST.get('email')
        attendance.phone = request.POST.get('phone')
        attendance.check_in = request.POST.get('check_in')
        attendance.check_out = request.POST.get('check_out')
        attendance.break_time = request.POST.get('break_time')
        attendance.lunch_time = request.POST.get('lunch_time')
        attendance.gender = request.POST.get('gender')
        attendance.job_id = request.POST.get('job')
        attendance.tags.set(request.POST.getlist('tags'))
        #attendance.is_married = request.POST.get('is_married')
        if request.POST.get('is_married') == 'on':
           attendance.is_married = True
        else:
           attendance.is_married = False
        attendance.joining_date = request.POST.get('joining_date')
        if request.FILES.get('image'):
            attendance.image = request.FILES.get('image')
        attendance.save()
        return redirect('/hr_attendances/detail/' + str(attendance_id) + '/')

@permission_required('hr_attendances.delete_attendancemodel', login_url='login')  
def delete_attendance(request, attendance_id):
    if request.method == "GET": 
        attendance = AttendanceModel.objects.get(id=attendance_id)  
        attendance.delete()
        return redirect('/hr_attendances/show_attendance/')